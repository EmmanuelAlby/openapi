import { Component, OnInit } from '@angular/core';
import { QaSuiteService } from '../service/suite.service';

@Component({
  selector: 'app-search-view',
  templateUrl: './search-view.component.html',
  styleUrls: ['./search-view.component.scss'],
  // providers:[QaSuiteService]
})
export class SearchViewComponent implements OnInit {
  response: any;

  constructor( /* private qaService: QaSuiteService */) { }

  ngOnInit() {
    const req= 'test';
    /* this.qaService.searchSuite(req).subscribe(res=>{
      this.response = res;
    }) */
  }

}
