import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { SearchViewComponent } from './search-view/search-view.component';
import { HeaderMenuComponent } from './header-menu/header-menu.component';
import { FooterMenuComponent } from './footer-menu/footer-menu.component';
import { LeftMenuComponent } from './left-menu/left-menu.component';
import { QaSuiteService } from './service/suite.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    SearchViewComponent,
    HeaderMenuComponent,
    FooterMenuComponent,
    LeftMenuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
